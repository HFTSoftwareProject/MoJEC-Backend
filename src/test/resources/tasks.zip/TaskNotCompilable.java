public class TaskNotCompilable {
    int a = 5
}

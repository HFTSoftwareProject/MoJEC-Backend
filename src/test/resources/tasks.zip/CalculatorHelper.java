import java.util.Arrays;

/**
 * Created by benno on 27.11.16.
 */
public class CalculatorHelper {
    public double sum(double... numbers) {
        return Arrays.stream(numbers).sum();
    }
}

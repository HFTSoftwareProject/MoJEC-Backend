/**
 * Created by benno on 20.11.16.
 */
public class Calculator {
    public double add(double a, double b) {
        return a + b;
    }

    public double sub(double a, double b) {
        return a - b;
    }

    public double mult(double a, double b) {
        return a * b;
    }

    public double div(double a, double b) {
        return a / b;
    }

    public double sum(double... numbers) {
        CalculatorHelper calculatorHelper = new CalculatorHelper();
        return calculatorHelper.sum(numbers);
    }
}
